variable "name" {
    description = "Name of the EC2 instance"
    type        = string
}

variable "ami" {
    description = "AMI ID for the EC2 instance"
    type        = string
}

variable "instance_type" { 
    description = "EC2 instance type"
    type        = string
}

variable "vpc_id" {
    description = "VPC ID for the EC2 instance"
    type        = string
}

variable "subnet_id" {
    description = "Subnet ID for the EC2 instance to launch into"
    type        = string
}

variable "security_group_id" {
    description = "Security group ID for the EC2 instance"
    type        = string
}

variable "vpc_cidr" {
  description = "CIDR block for the VPC"
  type        = string
}

variable "admin_cidr" {
    description = "Your IP in CIDR notation for SSH/UI access"
    type        = string
}

variable "key_name" {
    description = "Name of the EC2 key pair to use for SSH access"
    type        = string
}

variable "project_tag" {
    description = "Project tag for the EC2 instance and associated resources"
    type        = string
    default     = "Catalogix"
}

variable "role" {
    description = "Role tag for the EC2 instance and associated resources"
    type        = string
}

variable "azs" {
  description = "List of availability zones to use for the subnets"
  type        = list(string)
}

variable "public_subnets" {
  description = "List of CIDR blocks for the public subnets"
  type        = list(string)
}

variable "private_subnets" {
  description = "List of CIDR blocks for the private subnets"
  type        = list(string)
}

variable "cluster_name" {
  description = "Name of the EKS cluster"
  type        = string
}

